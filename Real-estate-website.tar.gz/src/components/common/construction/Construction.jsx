import Heading from "../../common/Heading"
import "./construction.css"

const Construction = () => {
  return (
    <>
      <section className='construction'>
        <div className='container'>
          <Heading title='Página en construcción ' subtitle='En servicio próximamente.' />
          
        </div>
      </section>
    </>
  )
}

export default Construction